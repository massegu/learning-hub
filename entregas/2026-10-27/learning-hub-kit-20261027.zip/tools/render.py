from pathlib import Path
from playwright.sync_api import sync_playwright
import json
import http.server, threading, functools
server=http.server.ThreadingHTTPServer(("127.0.0.1",8794),functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(Path(__file__).resolve().parents[1])))
threading.Thread(target=server.serve_forever,daemon=True).start()
R=Path(__file__).resolve().parents[1];D=R/'assets/documents/everyday-es-2026';U=R/'design-proposals'
manifest=json.loads((D/'manifest.json').read_text())
checks=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,args=['--no-sandbox'])
 for d in manifest['units']:
  page=browser.new_page(viewport={'width':d['width'],'height':d['height']},device_scale_factor=1)
  page.goto("http://127.0.0.1:8794/assets/documents/everyday-es-2026/"+d["id"]+".html");page.evaluate('document.fonts.ready')
  page.screenshot(path=str(D/f"{d['id']}.png"))
  page.pdf(path=str(D/f"{d['id']}.pdf"),width=f"{d['width']}px",height=f"{d['height']}px",print_background=True,margin={'top':'0','bottom':'0','left':'0','right':'0'},page_ranges='1')
  bottom=page.evaluate('''()=>Math.max(...[...document.querySelectorAll('h1,h2,h3,p,td,.row,.barcode')].map(e=>e.getBoundingClientRect().bottom))''')
  checks.append({'id':d['id'],'height':d['height'],'contentBottom':bottom,'withinCanvas':bottom<=d['height']-20})
  page.close()
 for name in ['a-calma','b-impulso','c-estudio','a-calma-exercise','b-impulso-exercise','c-estudio-exercise']:
  for label,w,h in [('desktop',1440,1150),('mobile',390,844)]:
   page=browser.new_page(viewport={'width':w,'height':h},device_scale_factor=1)
   page.goto('http://127.0.0.1:8794/design-proposals/'+name+'.html');page.evaluate('document.fonts.ready')
   assert page.evaluate('document.documentElement.scrollWidth<=innerWidth+1'),(name,label,'overflow')
   page.screenshot(path=str(U/f'{name}-{label}.png'),full_page=True)
   if not name.endswith('-exercise'):
    page.get_by_role('button',name='Sesión independiente',exact=True).click()
    assert 'no se añade' in page.locator('#modeNotice').inner_text()
   else:
    page.get_by_role('button',name='9 €',exact=True).click()
    assert 'Correcto:' in page.locator('#feedback').inner_text()
   page.close()
 page=browser.new_page(viewport={'width':1440,'height':1100})
 page.goto('http://127.0.0.1:8794/documents-overview.html')
 page.screenshot(path=str(R/'documents-overview.png'),full_page=True)
 page.close()
 browser.close()
(R/'render-checks.json').write_text(json.dumps(checks,indent=2))
print(json.dumps(checks,indent=2))
