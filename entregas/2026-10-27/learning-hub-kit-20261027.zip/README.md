# Learning Hub · documentos cotidianos y propuestas de diseño
Entrega: 27 de octubre de 2026.

## Qué contiene
- 12 documentos originales en PNG y PDF, con fuentes HTML editables.
- 12 transcripciones de texto y 48 preguntas con respuesta en el manifiesto JSON.
- 2 escenas fotográficas generadas con IA, con transcripción y 8 preguntas adicionales.
- 3 propuestas de diseño: Calma, Impulso y Estudio.
- Para cada diseño: inicio y ejercicio, en ordenador y móvil (12 capturas PNG en total).
- Maquetas HTML con interacciones de demostración. No conectan con ninguna API ni guardan datos.

Abre `index.html` en tu navegador después de descomprimir el ZIP. Puedes abrir los documentos, los PDF, las capturas completas y las maquetas desde esa galería.

## Cómo subir los recursos a GitHub
1. Descomprime el ZIP.
2. Abre el repositorio learning-hub en GitHub y selecciona la rama de trabajo donde quieras preparar la incorporación.
3. Pulsa Add file → Upload files.
4. Arrastra la carpeta `assets` de este paquete y conserva su estructura de subcarpetas.
5. Revisa que las rutas nuevas comiencen por `assets/documents/everyday-es-2026/` y `assets/scenes/everyday-es-2026/`.
6. Guarda el cambio en esa rama y revisa la PR antes de fusionar.

Ningún archivo de este paquete sustituye los iconos, las fotografías o los documentos existentes. Las propuestas de interfaz están en `design-proposals/`, fuera de los recursos que utiliza la aplicación.

IMPORTANTE: subir imágenes al repositorio NO las añade por sí solo a los ejercicios. Los manifiestos describen los recursos, pero hay que registrarlos en las bibliotecas del cliente y de la función de contenido, crear los ejercicios y publicar ambas partes para que aparezcan en la aplicación.

## Catálogo de documentos
1. airport-departures: salidas y cambio de puerta en un aeropuerto.
2. bus-shelter-ad: anuncio de línea de autobús de fin de semana.
3. museum-brochure: folleto de tres cuerpos de un museo y taller.
4. school-catalogue: catálogo con productos y oferta de un pack.
5. grocery-receipt: ticket estrecho con total, efectivo y cambio.
6. boarding-pass: tarjeta de embarque con aviso posterior de cambio de puerta.
7. video-recipe: captura de vídeo con subtítulo, tiempo y capítulos.
8. cinema-poster: cartel de cine con horario y alternativa por lluvia.
9. queue-display: pantalla de turnos y resguardo de ejemplo.
10. rail-disruption: aviso ferroviario con autobús alternativo.
11. online-order: pantalla de recogida con código, horario y pedido pagado.
12. sports-schedule: programa con edades, plazas y condiciones.

Todos los comercios, marcas, lugares operativos y códigos de estos documentos son ficticios. El dominio .example se usa deliberadamente como ejemplo. Los códigos de barras son decorativos y no deben usarse para validar billetes ni compras. Los documentos no son facturas oficiales, títulos de transporte ni material comercial real.

## Uso educativo
Las edades del manifiesto son orientativas para el documento, no garantizan que cada pregunta sea adecuada para toda la banda. Para 6–7 años, prioriza localizar un único dato y lectura acompañada; evita exigir inferencias o cálculos de tiempo que no se hayan trabajado. Para mayores, combina condiciones, compara datos y calcula diferencias. La respuesta correcta se conserva en el JSON; redacta distractores inequívocos al integrar preguntas de elección múltiple.

Las escenas de IA pueden contener pequeños detalles no realistas; se han escogido preguntas sobre elementos visibles y claros. No se pregunta la hora del reloj de la biblioteca ni se presupone una edad o un estado emocional a partir del aspecto de las personas.

## Propuestas de interfaz
A. Calma: continuidad con el verde actual, buena separación entre bloques y menos densidad visual. Recomendación como base.
B. Impulso: índigo, acento cálido y tarjetas compactas. Más energía para público adolescente, evitando premios o clasificaciones competitivas.
C. Estudio: sesiones recientes y modo de práctica en una columna lateral; orientado a preparar y revisar sesiones profesionales.

Recomendación: combinar Calma con la organización de seguimiento de Estudio. Mantener los iconos actuales, navegación predecible, instrucciones completas y un área central de ejercicio sin distracciones. El color no debería fijar el nivel ni sustituir las etiquetas de texto.

Las maquetas muestran datos ficticios. El historial con fecha y hora, el nuevo inicio y la nueva disposición del ejercicio son propuestas, NO cambios ya implementados. No se ha modificado el nombre de la plataforma. Se mantienen las áreas, incluidos English Lab y Geometría; en la implementación se mostrarán las que correspondan a la edad.

## Verificación
- 12 PNG de documentos y 12 PDF generados con texto legible y sin desbordamiento del lienzo.
- 12 capturas de diseño generadas en Chromium; ancho de móvil 390 px sin desbordamiento horizontal.
- Interacciones de demostración: cambio de modo de práctica y respuesta al ejercicio.
- Importes y ejemplos aritméticos comprobados al preparar los contenidos.
- La aplicación existente, Supabase, Stripe y GitHub no se han modificado.

## Autoría y recursos existentes
Los documentos y las maquetas se han creado para esta entrega. Las dos escenas se han generado con IA para Learning Hub. `design-proposals/learning-areas-3d.png` es una copia sin cambios del sprite original que ya existe en el repositorio, reutilizada para mostrar continuidad visual. No se han incorporado fotografías de terceros ni identidades reales.
